# NLP_chatbot_for_senior_citizens

NTU MLDA Deep Learning Week Hackathon: NLP chatbot for senior citizens. 

Team: 405 Found

Youtube link: https://www.youtube.com/watch?v=56yBD6ern8k 

Contributors: Joshua, Yi Jie, Xiao Ming, Yu Tian

Github accounts: @Yijie-Ding (to be updated later)

---

### **Overview**

This is a project done for NTU MLDA Deep Learning Week Hackathon. 

Our aim was to develop a chatbot for senior citizens in Singapore. 

Here's the [demo video](https://www.youtube.com/watch?v=56yBD6ern8k ) for the project.

---

### **File navigation**

- To be updated later
